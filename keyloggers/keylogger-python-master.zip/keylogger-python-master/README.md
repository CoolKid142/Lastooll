# keylogger-python

## To run it in your machine for testing
* run the command
*  ### pip install -r requirements.txt
* to download the dependencies required for the project
    
## Things achieved:
* Listen to keystrokes
* Take screenshot periodically
* Also sent the text copied to the clipboard

## Things to add or can be added by anyone
* Get which programs are being opened by the user
* Get browser history

# Note:
To get it run in victim computer bcoz the victim will not run a python file on its own you can convert python file to an exe file using
* auto-py-to-exe module
* pyinstaller module

